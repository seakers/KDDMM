%% Extract and determine unqie designs with full feasibility and stability from csv files
clear
clc

%% Extract fully feasible and stable designs from csv files
filename1 = "EpsilonMOEA_emoea_";
filename2 = "fscon0__fibre.csv";

n_runs = 30;

designs_feas_and_stab_allruns = [];

for i = 1:n_runs
    full_filepath = strcat(filename1,num2str(i-1),filename2);
    data_table = readtable(full_filepath,'Format','%s%f%f%f%f','HeaderLines',1);

    %%%% store retrieved data into different variables
    %%%% csv_data includes: [Pen. Obj. 1, Pen.Obj. 2, Feasibility Score,
    %%%% Stablity Score]
    pop_size =  size(data_table,1);
    csv_data = zeros(pop_size,4);
    designs = strings(pop_size);
    csv_data = data_table(:,2:end);
    designs = data_table(:,1);
    
    csv_data_array = table2array(csv_data);
    designs_array = table2array(designs);
    
    feas_array = csv_data_array(:,3);
    stab_array = csv_data_array(:,4);
    
    designs_array_feas_and_stab = designs_array((feas_array == 1) & (stab_array == 1));
    designs_feas_and_stab_allruns = [designs_feas_and_stab_allruns;designs_array_feas_and_stab];
end

%% Remove non-unique designs 
designs_allruns_unique = unique(designs_feas_and_stab_allruns);
